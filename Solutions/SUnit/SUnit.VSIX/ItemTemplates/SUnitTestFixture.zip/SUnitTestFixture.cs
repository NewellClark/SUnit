﻿using System;
using System.Collections.Generic;
using System.Text;
using SUnit;

namespace $rootnamespace$
{
    public class $safeitemname$
    {
        public Test TestMethod()
        {
            return Test.Fail;
        }
    }
}
